package assignment1.package3;

/**
 * EditedVolume Class extends Book.
 */
public class EditedVolume extends Book {

  public EditedVolume(String title, String[] authors, int publishingYear, int numberOfCitations,
      String publishingCompany, String numberOfPages) {
    super(title, authors, publishingYear, numberOfCitations, publishingCompany, numberOfPages);
  }
}
