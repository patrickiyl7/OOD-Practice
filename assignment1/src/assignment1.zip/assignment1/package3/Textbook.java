package assignment1.package3;

/**
 * Textbook Class extends Book.
 */
public class Textbook extends Book {

  public Textbook(String title, String[] authors, int publishingYear, int numberOfCitations,
      String publishingCompany, String numberOfPages) {
    super(title, authors, publishingYear, numberOfCitations, publishingCompany, numberOfPages);
  }
}
