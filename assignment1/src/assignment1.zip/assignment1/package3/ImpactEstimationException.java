package assignment1.package3;

public class ImpactEstimationException extends Exception {

  public ImpactEstimationException() {
  }

  public ImpactEstimationException(String message) {
    super(message);
  }
}
