package assignment1.package3;

public class Article extends Publication {

  public Article(String title, String[] authors, int publishingYear, int numberOfCitations) {
    super(title, authors, publishingYear, numberOfCitations);
  }
}
