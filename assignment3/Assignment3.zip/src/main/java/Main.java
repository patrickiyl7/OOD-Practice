public class Main {

  /**
   * main function of the project
   *
   * @param args input by user.
   * @throws Exception thrown if user input wrong arguments.
   */
  public static void main(String[] args) throws Exception {
    new GenerateFiles().GenerateResults(args);
  }
}
